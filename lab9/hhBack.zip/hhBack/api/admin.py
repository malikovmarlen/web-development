from django.contrib import admin

# Register your models here.
from api.models import Company, Vacancy

# admin.site.register(Company)
# admin.site.register(Vacancy)

@admin.register(Vacancy)
class VacancyAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'salary', 'company',)
    # search_fields = ('name', 'salary', 'company',)
    list_filter = ('company',)

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'city', 'address',)
    list_filter = ('city',)